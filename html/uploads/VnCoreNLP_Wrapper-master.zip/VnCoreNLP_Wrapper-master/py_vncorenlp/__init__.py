# -*- coding: utf-8 -*-
from py_vncorenlp.vncorenlp import VnCoreNLP, download_model

__version__ = "0.1.4"
__all__ = [
    "download_model",
    "VnCoreNLP"
]