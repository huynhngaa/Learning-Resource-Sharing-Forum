<!DOCTYPE html>
<html>
<head>
    <title>Tìm kiếm văn bản</title>
</head>
<body>
    <h1>Tìm kiếm văn bản</h1>
    <form method="post" action="timkiem.php">
        <input type="text" name="keyword" placeholder="Nhập từ khóa">
        <input type="submit" value="Tìm kiếm">
    </form>

    <div id="results">
        <!-- Kết quả tìm kiếm sẽ được hiển thị ở đây -->
    </div>
</body>
</html>
