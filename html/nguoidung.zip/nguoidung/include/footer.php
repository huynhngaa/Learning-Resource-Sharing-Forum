
<footer class="footer bg-dark fixed-bottom">
    <div class="container-fluid d-flex flex-md-row flex-column justify-content-between align-items-md-center gap-1 container-p-x py-3">
      <div>
      <a class="navbar-brand " href="index.php"><img width="100px" src="../assets/img/favicon/logo2.png" alt=""></a>

      </div>
      <div>
        <a href="index.php" class="footer-link text-light me-4" >Trang Chủ</a>
        <a href="#" class="footer-link text-light me-4">Liên Hệ</a>
        <a onclick="logout()" href="#" class="footer-link text-light me-4">Đăng xuất</a>
      </div>
    </div>
  </footer>