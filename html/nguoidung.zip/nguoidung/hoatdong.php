



  <div class="demo-inline-spacing mt-3">
                        <div class="list-group list-group-flush">
                          <a href="ls-binhluan.php?id=<?php echo $id ?>" class="list-group-item list-group-item-action">
                            <span class="badge badge-center rounded-pill bg-label-secondary"><i class="fa-solid fa-comment"></i></span> Bình Luận  </a>
                          <a href="ls-danhgia.php?id=<?php echo $id ?>" class="list-group-item list-group-item-action">
                          <span class="badge badge-center rounded-pill bg-label-secondary"><i class=" fa-solid fa-star"></i></span> Đánh giá của bạn</a>
                          <a href="ls-xem.php?id=<?php echo $id ?>" class="list-group-item list-group-item-action">
                          <span class="badge badge-center rounded-pill bg-label-secondary"><i class="fa-solid fa-eye"></i></span> Bài viết bạn đã xem</a>
                        
                        </div>
                      </div>
